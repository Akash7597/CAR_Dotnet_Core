--Get All Product All Products-- 

CREATE PROCEDURE SP_GetAllProductsDetails
AS
BEGIN
	SELECT * FROM ProductDetails
END
GO

	--Add New Products--
CREATE PROCEDURE SP_CreateNewProduct
(
	@ProductCode varchar(50) = ' ',
	@ProductName varchar(250) = ' ',
	@ProductDescription varchar(4000) = ' ',
	@ProductCategory varchar(50) = ' ',
	@ExpiryDate Varchar(50)=' ',
	@CurrentDate Varchar(50)=' ',
	@Status varchar(50)=' '
)
AS
BEGIN
	INSERT INTO ProductDetails(ProductCode,ProductCategory,ProductDescription,ProductCategory,ExpiryDate,CurrentDate,Status)
	VALUES (@ProductCode, @ProductCategory, @ProductDescription, @ProductCategory, @ExpiryDate, @CurrentDate, @Status)

END
GO

	-- Update Products --
CREATE PROCEDURE SP_UpdateNewProduct
(
	@ProductCode varchar(50) = ' ',
	@ProductName varchar(250) = ' ',
	@ProductDescription varchar(4000) = ' ',
	@ProductCategory varchar(50) = ' ',
	@ExpiryDate Varchar(50)=' ',
	@CurrentDate Varchar(50)=' ',
	@Status varchar(50)=' '
)
AS
BEGIN
	UPDATE ProductDetails SET ProductCode = @ProductCode, ProductName = @ProductName, ProductDescription = @ProductDescription,
			ExpiryDate = @ExpiryDate, CurrentDate = @CurrentDate, Status = @Status
		where ProductName = @ProductName

END
GO

	--Delete Products--
CREATE PROCEDURE SP_DeleteProduct
(
	@ProductId int = 0
)

AS
BEGIN
	
	DELETE FROM ProductDetails WHERE ProductId = @ProductId 

END
GO

	--Get ProductDetailsById --
CREATE PROCEDURE SP_ProductById
(
	@ProductId int = 0
)

AS
BEGIN
	Select * From ProductDetails
	Where ProductId = @ProductId
END
GO