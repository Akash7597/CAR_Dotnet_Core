﻿using Car.Data;
using Car.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Car.Controllers
{
    public class ProductController : Controller
    {
        private readonly ApplicationContext applicationContext;
        public ProductController(ApplicationContext applicationContext)
        {
            this.applicationContext= applicationContext;
        }
        [HttpGet]
        public async Task<IActionResult> Index(string sortOrder, int pageNumber=1)
        {
            var products = applicationContext.ProductDetails.AsQueryable();
            ViewData["NameOrder"] = String.IsNullOrEmpty(sortOrder) ? "name_desc" : "";
            switch(sortOrder)
            {
                case "name_desc":
                    products=products.OrderByDescending(x => x.ProductName);
                    break;

                default:
                    products=products.OrderBy(x => x.ProductName);
                    break;
            }
            return View(await PaginatedList<ProductDetails>.CreateAsync(applicationContext.ProductDetails, pageNumber, 5));
        }

        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }
        [HttpPost]
        //ADD A PRODUCT
        public async Task<IActionResult> Add(AddProductViewModel addProductRequest)
        {
            var product = new ProductDetails()
            {
                ProductCode = addProductRequest.ProductCode,
                ProductName = addProductRequest.ProductName,
                ProductDescription = addProductRequest.ProductDescription,
                ProductCategory = addProductRequest.ProductCategory,
                //Image = addProductRequest.Image,
                ExpiryDate = addProductRequest.ExpiryDate,
                CurrentDate = addProductRequest.CurrentDate,
                Status = addProductRequest.Status
        };
            await applicationContext.ProductDetails.AddAsync(product);
            await applicationContext.SaveChangesAsync();
            return RedirectToAction("Index");            
        }

        [HttpGet]
        //UPDATE OR EDIT A PRODUCT
        public async Task<IActionResult> View(int id)
        {
            var product = await applicationContext.ProductDetails.FirstOrDefaultAsync(x => x.ProductId == id);
            
            if(product!=null)
            {
                var viewModel = new UpdateProductViewModel()
                {
                    ProductId= product.ProductId,
                    ProductCode = product.ProductCode,
                    ProductName = product.ProductName,
                    ProductDescription = product.ProductDescription,
                    ProductCategory = product.ProductCategory,
                    ExpiryDate = product.ExpiryDate,
                    CurrentDate = product.CurrentDate,
                    Status = product.Status
                };
                return await Task.Run(() => View("View", viewModel));
            }
            return RedirectToAction("Index");
        }
        [HttpPost]
        public async Task<IActionResult> View(UpdateProductViewModel model)
        {
            var product = await applicationContext.ProductDetails.FindAsync(model.ProductId);
            
            if(product != null)
            {
                product.ProductCode=model.ProductCode;
                product.ProductName=model.ProductName;
                product.ProductDescription=model.ProductDescription;
                product.ProductCategory=model.ProductCategory;
                product.ExpiryDate=model.ExpiryDate;
                product.CurrentDate=model.CurrentDate;
                product.Status = model.Status;

                await applicationContext.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            return RedirectToAction("Index");
        }

        [HttpPost]
        // DELETE A PRODUCT 
        public async Task<IActionResult> Delete(UpdateProductViewModel model)
        {
            var product = await applicationContext.ProductDetails.FindAsync(model.ProductId);
            if(product != null)
            {
                applicationContext.ProductDetails.Remove(product);
                await applicationContext.SaveChangesAsync();

                return RedirectToAction("Index");
            }
            return RedirectToAction("Index");
        }
    }
}
