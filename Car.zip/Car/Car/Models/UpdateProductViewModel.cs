﻿using System.ComponentModel.DataAnnotations;

namespace Car.Models
{
    public class UpdateProductViewModel
    {
        [Key]
        public int ProductId { get; set; }
        [Required]
        public int ProductCode { get; set; }
        [Required]
        [MaxLength(250)]
        public string ProductName { get; set; }
        [Required]
        [MaxLength(4000)]
        public string ProductDescription { get; set; }
        [Required]
        public string ProductCategory { get; set; }
        //[Required]
        //public IFormFile Image { get; set; }
        [Required]
        public DateTime ExpiryDate { get; set; }
        public DateTime CurrentDate { get; set; } = DateTime.Now;
        [Required]
        public string Status { get; set; }
    }
}
